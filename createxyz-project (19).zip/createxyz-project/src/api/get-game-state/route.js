async function handler({ gameId, playerId }) {
  if (!gameId) {
    return { error: "Game ID is required" };
  }

  try {
    const session = await sql`
      SELECT id, game_id, status, mode, current_ball, drawn_balls, 
             current_question_id, round_number, created_at, updated_at
      FROM game_sessions 
      WHERE game_id = ${gameId}
    `;

    if (session.length === 0) {
      return { error: "Game not found" };
    }

    const sessionData = session[0];
    const sessionId = sessionData.id;

    const players = await sql`
      SELECT id, nickname, avatar, status, wins, marked_cells, last_seen
      FROM players 
      WHERE session_id = ${sessionId}
      ORDER BY created_at ASC
    `;

    let currentQuestion = null;
    if (sessionData.current_question_id) {
      const questionResult = await sql`
        SELECT id, question, answers, correct_answer, time_limit, media_url
        FROM trivia_questions 
        WHERE id = ${sessionData.current_question_id}
      `;
      if (questionResult.length > 0) {
        currentQuestion = questionResult[0];
      }
    }

    const recentEvents = await sql`
      SELECT event_type, event_data, created_at
      FROM game_events 
      WHERE session_id = ${sessionId}
      ORDER BY created_at DESC 
      LIMIT 10
    `;

    let playerData = null;
    if (playerId) {
      const playerResult = await sql`
        SELECT id, nickname, avatar, bingo_card, marked_cells, wins, status
        FROM players 
        WHERE id = ${playerId} AND session_id = ${sessionId}
      `;
      if (playerResult.length > 0) {
        playerData = playerResult[0];
      }
    }

    return {
      success: true,
      session: {
        id: sessionData.id,
        gameId: sessionData.game_id,
        status: sessionData.status,
        mode: sessionData.mode,
        currentBall: sessionData.current_ball,
        drawnBalls: sessionData.drawn_balls || [],
        currentQuestionId: sessionData.current_question_id,
        roundNumber: sessionData.round_number,
        playerCount: players.length,
        createdAt: sessionData.created_at,
        updatedAt: sessionData.updated_at,
      },
      players: players.map((player) => ({
        id: player.id,
        nickname: player.nickname,
        avatar: player.avatar,
        status: player.status,
        wins: player.wins,
        markedCells: player.marked_cells || [],
        lastSeen: player.last_seen,
      })),
      currentQuestion: currentQuestion
        ? {
            id: currentQuestion.id,
            question: currentQuestion.question,
            answers: currentQuestion.answers,
            correctAnswer: currentQuestion.correct_answer,
            timeLimit: currentQuestion.time_limit,
            mediaUrl: currentQuestion.media_url,
          }
        : null,
      recentEvents: recentEvents.map((event) => ({
        type: event.event_type,
        data: event.event_data,
        timestamp: event.created_at,
      })),
      player: playerData
        ? {
            id: playerData.id,
            nickname: playerData.nickname,
            avatar: playerData.avatar,
            bingoCard: playerData.bingo_card,
            markedCells: playerData.marked_cells || [],
            wins: playerData.wins,
            status: playerData.status,
          }
        : null,
    };
  } catch (error) {
    return { error: "Failed to get game state: " + error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}