async function handler({ gameId, nickname, avatar = "high-roller" }) {
  if (!gameId || !nickname) {
    return { error: "Game ID and nickname are required" };
  }

  try {
    // Find the session by game_id (session code)
    const session = await sql`
      SELECT id, status, mode, game_id, current_ball, drawn_balls, round_number
      FROM game_sessions 
      WHERE game_id = ${gameId} AND status IN ('waiting', 'active')
    `;

    if (session.length === 0) {
      return {
        error:
          "Game session not found or not accepting players. Please check your session code.",
      };
    }

    const sessionId = session[0].id;

    // Check if nickname is already taken in this session
    const existingPlayer = await sql`
      SELECT id FROM players 
      WHERE session_id = ${sessionId} AND nickname = ${nickname} AND status != 'kicked'
    `;

    if (existingPlayer.length > 0) {
      return { error: "Nickname already taken in this game session" };
    }

    // Generate bingo card
    const bingoCard = generateBingoCard();

    // Create new player
    const [player] = await sql`
      INSERT INTO players (session_id, nickname, avatar, bingo_card, status)
      VALUES (${sessionId}, ${nickname}, ${avatar}, ${bingoCard}, 'active')
      RETURNING id, nickname, avatar, bingo_card, wins, status, created_at, marked_cells
    `;

    // Log join event
    await sql`
      INSERT INTO game_events (session_id, event_type, event_data)
      VALUES (${sessionId}, 'player_joined', ${JSON.stringify({
      playerId: player.id,
      nickname: nickname,
      avatar: avatar,
      timestamp: new Date().toISOString(),
    })})
    `;

    // Get current player count
    const playerCount = await sql`
      SELECT COUNT(*) as count FROM players 
      WHERE session_id = ${sessionId} AND status = 'active'
    `;

    return {
      success: true,
      player: {
        id: player.id,
        nickname: player.nickname,
        avatar: player.avatar,
        bingoCard: player.bingo_card,
        wins: player.wins,
        status: player.status,
        markedCells: player.marked_cells || [],
      },
      session: {
        id: sessionId,
        gameId: session[0].game_id,
        status: session[0].status,
        mode: session[0].mode,
        playerCount: parseInt(playerCount[0].count),
        currentBall: session[0].current_ball,
        drawnBalls: session[0].drawn_balls || [],
        roundNumber: session[0].round_number,
      },
    };
  } catch (error) {
    console.error("Join game error:", error);
    return { error: "Failed to join game: " + error.message };
  }
}

function generateBingoCard() {
  const card = [];
  const ranges = [
    [1, 15], // B
    [16, 30], // I
    [31, 45], // N
    [46, 60], // G
    [61, 75], // O
  ];

  for (let col = 0; col < 5; col++) {
    const column = [];
    const [min, max] = ranges[col];
    const used = new Set();

    for (let row = 0; row < 5; row++) {
      if (col === 2 && row === 2) {
        column.push(0); // FREE space
      } else {
        let num;
        do {
          num = Math.floor(Math.random() * (max - min + 1)) + min;
        } while (used.has(num));
        used.add(num);
        column.push(num);
      }
    }
    card.push(column);
  }

  return card.flat();
}
export async function POST(request) {
  return handler(await request.json());
}