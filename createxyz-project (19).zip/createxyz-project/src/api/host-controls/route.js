async function handler({ action, gameId, playerId, gameMode, questionData }) {
  if (!action) {
    return { error: "Action is required" };
  }

  try {
    switch (action) {
      case "create_session":
        if (!gameId) {
          return { error: "Game ID is required to create session" };
        }

        // Check if session already exists
        const existingSession = await sql`
          SELECT id FROM game_sessions WHERE game_id = ${gameId}
        `;

        if (existingSession.length > 0) {
          return { error: "Session with this ID already exists" };
        }

        // Create new session
        const [newSession] = await sql`
          INSERT INTO game_sessions (game_id, status, mode, round_number)
          VALUES (${gameId}, 'waiting', 'bingo', 1)
          RETURNING id, game_id, status, mode, round_number, created_at
        `;

        // Log session creation event
        await sql`
          INSERT INTO game_events (session_id, event_type, event_data)
          VALUES (${newSession.id}, 'session_created', ${JSON.stringify({
          gameId: gameId,
          timestamp: new Date().toISOString(),
        })})
        `;

        return {
          success: true,
          message: `Session ${gameId} created successfully`,
          session: {
            id: newSession.id,
            gameId: newSession.game_id,
            status: newSession.status,
            mode: newSession.mode,
            roundNumber: newSession.round_number,
            createdAt: newSession.created_at,
          },
        };

      case "start_game":
        if (!gameId) {
          return { error: "Game ID is required" };
        }

        const startSession = await sql`
          SELECT id FROM game_sessions WHERE game_id = ${gameId}
        `;

        if (startSession.length === 0) {
          return { error: "Game session not found" };
        }

        await sql`
          UPDATE game_sessions 
          SET status = 'active', updated_at = now()
          WHERE game_id = ${gameId}
        `;

        await sql`
          INSERT INTO game_events (session_id, event_type, event_data)
          VALUES (${startSession[0].id}, 'game_started', ${JSON.stringify({
          timestamp: new Date().toISOString(),
        })})
        `;

        return { success: true, status: "active", message: "Game started" };

      case "pause_game":
        if (!gameId) {
          return { error: "Game ID is required" };
        }

        const pauseSession = await sql`
          SELECT id FROM game_sessions WHERE game_id = ${gameId}
        `;

        if (pauseSession.length === 0) {
          return { error: "Game session not found" };
        }

        await sql`
          UPDATE game_sessions 
          SET status = 'paused', updated_at = now()
          WHERE game_id = ${gameId}
        `;

        await sql`
          INSERT INTO game_events (session_id, event_type, event_data)
          VALUES (${pauseSession[0].id}, 'game_paused', ${JSON.stringify({
          timestamp: new Date().toISOString(),
        })})
        `;

        return { success: true, status: "paused", message: "Game paused" };

      case "switch_mode":
        if (!gameId || !gameMode) {
          return { error: "Game ID and game mode are required" };
        }

        const switchSession = await sql`
          SELECT id, status FROM game_sessions WHERE game_id = ${gameId}
        `;

        if (switchSession.length === 0) {
          return { error: "Game session not found" };
        }

        if (switchSession[0].status === "active") {
          return { error: "Cannot switch mode while game is active" };
        }

        await sql`
          UPDATE game_sessions 
          SET mode = ${gameMode}, updated_at = now()
          WHERE game_id = ${gameId}
        `;

        await sql`
          INSERT INTO game_events (session_id, event_type, event_data)
          VALUES (${switchSession[0].id}, 'mode_switched', ${JSON.stringify({
          newMode: gameMode,
          timestamp: new Date().toISOString(),
        })})
        `;

        return {
          success: true,
          mode: gameMode,
          message: `Switched to ${gameMode} mode`,
        };

      case "kick_player":
        if (!playerId) {
          return { error: "Player ID is required" };
        }

        const kickResult = await sql`
          UPDATE players 
          SET status = 'kicked', last_seen = now()
          WHERE id = ${playerId}
          RETURNING session_id, nickname
        `;

        if (kickResult.length === 0) {
          return { error: "Player not found" };
        }

        await sql`
          INSERT INTO game_events (session_id, event_type, event_data)
          VALUES (${
            kickResult[0].session_id
          }, 'player_kicked', ${JSON.stringify({
          playerId: playerId,
          nickname: kickResult[0].nickname,
          timestamp: new Date().toISOString(),
        })})
        `;

        return {
          success: true,
          message: `Player ${kickResult[0].nickname} has been kicked`,
        };

      case "end_round":
        if (!gameId) {
          return { error: "Game ID is required" };
        }

        const endSession = await sql`
          SELECT id, round_number FROM game_sessions WHERE game_id = ${gameId}
        `;

        if (endSession.length === 0) {
          return { error: "Game session not found" };
        }

        const newRoundNumber = endSession[0].round_number + 1;

        await sql`
          UPDATE game_sessions 
          SET round_number = ${newRoundNumber}, 
              current_ball = null, 
              drawn_balls = '{}',
              status = 'waiting',
              updated_at = now()
          WHERE game_id = ${gameId}
        `;

        // Reset all player marked cells for new round
        await sql`
          UPDATE players 
          SET marked_cells = '{}'
          WHERE session_id = ${endSession[0].id}
        `;

        await sql`
          INSERT INTO game_events (session_id, event_type, event_data)
          VALUES (${endSession[0].id}, 'round_ended', ${JSON.stringify({
          oldRound: endSession[0].round_number,
          newRound: newRoundNumber,
          timestamp: new Date().toISOString(),
        })})
        `;

        return {
          success: true,
          message: `Round ${endSession[0].round_number} ended. Starting Round ${newRoundNumber}!`,
        };

      case "announce_winner":
        if (!playerId) {
          return { error: "Player ID is required" };
        }

        const winnerResult = await sql`
          UPDATE players 
          SET wins = wins + 1
          WHERE id = ${playerId}
          RETURNING session_id, nickname, wins
        `;

        if (winnerResult.length === 0) {
          return { error: "Player not found" };
        }

        await sql`
          INSERT INTO game_events (session_id, event_type, event_data)
          VALUES (${
            winnerResult[0].session_id
          }, 'winner_announced', ${JSON.stringify({
          playerId: playerId,
          nickname: winnerResult[0].nickname,
          totalWins: winnerResult[0].wins,
          timestamp: new Date().toISOString(),
        })})
        `;

        return {
          success: true,
          message: `🎉 ${winnerResult[0].nickname} wins! Total wins: ${winnerResult[0].wins}`,
        };

      case "view_player_card":
        if (!playerId) {
          return { error: "Player ID is required" };
        }

        const playerCard = await sql`
          SELECT id, nickname, avatar, bingo_card, marked_cells, wins, status
          FROM players 
          WHERE id = ${playerId}
        `;

        if (playerCard.length === 0) {
          return { error: "Player not found" };
        }

        return {
          success: true,
          player: {
            id: playerCard[0].id,
            nickname: playerCard[0].nickname,
            avatar: playerCard[0].avatar,
            bingoCard: playerCard[0].bingo_card,
            markedCells: playerCard[0].marked_cells || [],
            wins: playerCard[0].wins,
            status: playerCard[0].status,
          },
        };

      case "add_question":
        if (!gameId || !questionData) {
          return { error: "Game ID and question data are required" };
        }

        const addSession = await sql`
          SELECT id FROM game_sessions WHERE game_id = ${gameId}
        `;

        if (addSession.length === 0) {
          return { error: "Game session not found" };
        }

        const [newQuestion] = await sql`
          INSERT INTO trivia_questions (session_id, question, answers, correct_answer, time_limit, media_url)
          VALUES (${addSession[0].id}, ${questionData.question}, ${questionData.answers}, ${questionData.correctAnswer}, ${questionData.timeLimit}, ${questionData.mediaUrl})
          RETURNING id
        `;

        return {
          success: true,
          message: "Question added successfully",
          questionId: newQuestion.id,
        };

      case "update_question":
        if (!questionData || !questionData.id) {
          return { error: "Question data with ID is required" };
        }

        await sql`
          UPDATE trivia_questions 
          SET question = ${questionData.question},
              answers = ${questionData.answers},
              correct_answer = ${questionData.correctAnswer},
              time_limit = ${questionData.timeLimit},
              media_url = ${questionData.mediaUrl}
          WHERE id = ${questionData.id}
        `;

        return { success: true, message: "Question updated successfully" };

      default:
        return { error: "Unknown action" };
    }
  } catch (error) {
    console.error("Host controls error:", error);
    return { error: "Failed to execute action: " + error.message };
  }
}
export async function POST(request) {
  return handler(await request.json());
}