async function handler({ playerId, markedCells, gameId }) {
  if (!playerId || !markedCells || !gameId) {
    return { error: "Player ID, marked cells, and game ID are required" };
  }

  try {
    const player = await sql`
      SELECT p.id, p.session_id, p.bingo_card, p.marked_cells, p.wins,
             s.drawn_balls, s.status
      FROM players p
      JOIN game_sessions s ON p.session_id = s.id
      WHERE p.id = ${playerId} AND s.game_id = ${gameId}
    `;

    if (player.length === 0) {
      return { error: "Player not found in this game" };
    }

    const playerData = player[0];
    const bingoCard = playerData.bingo_card;
    const drawnBalls = playerData.drawn_balls || [];

    const validMarkedCells = [];
    for (const cellIndex of markedCells) {
      const index = parseInt(cellIndex);
      if (index >= 0 && index < 25) {
        const cellValue = bingoCard[index];
        if (cellValue === 0 || drawnBalls.includes(cellValue)) {
          validMarkedCells.push(cellIndex);
        }
      }
    }

    const hasBingo = checkForBingo(validMarkedCells);

    let newWins = playerData.wins;
    if (hasBingo && !playerData.marked_cells.includes("BINGO")) {
      newWins = playerData.wins + 1;
      validMarkedCells.push("BINGO");

      await sql`
        INSERT INTO game_events (session_id, event_type, event_data)
        VALUES (${playerData.session_id}, 'bingo_winner', ${JSON.stringify({
        playerId: playerId,
        winType: "bingo",
        markedCells: validMarkedCells,
      })})
      `;
    }

    await sql`
      UPDATE players 
      SET marked_cells = ${validMarkedCells}, 
          wins = ${newWins},
          last_seen = now()
      WHERE id = ${playerId}
    `;

    return {
      success: true,
      player: {
        id: playerId,
        markedCells: validMarkedCells,
        wins: newWins,
        hasBingo: hasBingo,
      },
      validatedCells: validMarkedCells.length,
      invalidCells: markedCells.length - validMarkedCells.length,
    };
  } catch (error) {
    return { error: "Failed to update player card: " + error.message };
  }
}

function checkForBingo(markedCells) {
  const marked = new Set(markedCells.map((cell) => parseInt(cell)));

  const winPatterns = [
    [0, 1, 2, 3, 4],
    [5, 6, 7, 8, 9],
    [10, 11, 12, 13, 14],
    [15, 16, 17, 18, 19],
    [20, 21, 22, 23, 24],
    [0, 5, 10, 15, 20],
    [1, 6, 11, 16, 21],
    [2, 7, 12, 17, 22],
    [3, 8, 13, 18, 23],
    [4, 9, 14, 19, 24],
    [0, 6, 12, 18, 24],
    [4, 8, 12, 16, 20],
  ];

  for (const pattern of winPatterns) {
    if (pattern.every((index) => marked.has(index))) {
      return true;
    }
  }

  return false;
}
export async function POST(request) {
  return handler(await request.json());
}