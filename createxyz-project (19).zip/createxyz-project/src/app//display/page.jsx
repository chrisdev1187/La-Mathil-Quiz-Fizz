"use client";
import React from "react";

function MainComponent() {
  const [gameState, setGameState] = React.useState(null);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState("");
  const [selectedSession, setSelectedSession] = React.useState("VB-2025");
  const [animationState, setAnimationState] = React.useState("idle"); // idle, whirlwind, selection
  const [selectedBall, setSelectedBall] = React.useState(null);
  const [ballPositions, setBallPositions] = React.useState([]);
  const [physicsEngine, setPhysicsEngine] = React.useState(null);
  const containerRef = React.useRef(null);
  const ballsRef = React.useRef([]);

  // Initialize physics engine and balls
  React.useEffect(() => {
    if (typeof window === "undefined") return;

    // Create physics engine (simplified version without Matter.js)
    const engine = {
      gravity: 1,
      vortexStrength: 0,
      balls: [],
    };

    // Generate all 75 bingo balls
    const balls = [];
    for (let i = 1; i <= 75; i++) {
      const ball = {
        id: i,
        number: i,
        letter:
          i <= 15 ? "B" : i <= 30 ? "I" : i <= 45 ? "N" : i <= 60 ? "G" : "O",
        x: Math.random() * 400 + 100, // Random position in container
        y: Math.random() * 200 + 300, // Start near bottom
        vx: 0, // velocity x
        vy: 0, // velocity y
        radius: 20,
        isStatic: false,
        isSelected: false,
      };
      balls.push(ball);
    }

    engine.balls = balls;
    setPhysicsEngine(engine);
    setBallPositions(balls);

    // Physics simulation loop
    const animate = () => {
      if (engine.balls.length === 0) return;

      engine.balls.forEach((ball) => {
        if (ball.isStatic) return;

        // Apply gravity
        ball.vy += engine.gravity * 0.1;

        // Apply vortex force if active
        if (engine.vortexStrength > 0) {
          const centerX = 300;
          const centerY = 250;
          const dx = centerX - ball.x;
          const dy = centerY - ball.y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance > 0) {
            // Tangential force for vortex
            const forceX = (-dy / distance) * engine.vortexStrength;
            const forceY = (dx / distance) * engine.vortexStrength;

            ball.vx += forceX * 0.02;
            ball.vy += forceY * 0.02;

            // Add some randomness for chaos
            ball.vx += (Math.random() - 0.5) * 0.5;
            ball.vy += (Math.random() - 0.5) * 0.5;
          }
        }

        // Update position
        ball.x += ball.vx;
        ball.y += ball.vy;

        // Boundary collision (circular container)
        const centerX = 300;
        const centerY = 250;
        const containerRadius = 200;
        const dx = ball.x - centerX;
        const dy = ball.y - centerY;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance + ball.radius > containerRadius) {
          const angle = Math.atan2(dy, dx);
          ball.x = centerX + Math.cos(angle) * (containerRadius - ball.radius);
          ball.y = centerY + Math.sin(angle) * (containerRadius - ball.radius);

          // Bounce off walls
          const normalX = dx / distance;
          const normalY = dy / distance;
          const dotProduct = ball.vx * normalX + ball.vy * normalY;
          ball.vx -= 2 * dotProduct * normalX * 0.8; // Some energy loss
          ball.vy -= 2 * dotProduct * normalY * 0.8;
        }

        // Apply friction
        ball.vx *= 0.98;
        ball.vy *= 0.98;

        // Ground collision when gravity is on
        if (engine.gravity > 0 && ball.y > 400) {
          ball.y = 400;
          ball.vy *= -0.3; // Bounce with energy loss
        }
      });

      setBallPositions([...engine.balls]);
      requestAnimationFrame(animate);
    };

    animate();

    return () => {
      // Cleanup
    };
  }, []);

  // Load game state on mount and set up polling
  React.useEffect(() => {
    loadGameState();
    const interval = setInterval(loadGameState, 3000); // Poll every 3 seconds
    return () => clearInterval(interval);
  }, [selectedSession]);

  // Watch for ball draws and trigger animations
  React.useEffect(() => {
    if (gameState?.session?.currentBall && physicsEngine) {
      const currentBall = gameState.session.currentBall;
      const lastDrawnBall =
        gameState.session.drawnBalls[gameState.session.drawnBalls.length - 1];

      // Only animate if this is a new ball draw
      if (currentBall === lastDrawnBall && animationState === "idle") {
        triggerBallDrawAnimation(currentBall);
      }
    }
  }, [gameState?.session?.currentBall, physicsEngine]);

  const loadGameState = async () => {
    try {
      const response = await fetch("/api/get-game-state", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ gameId: selectedSession }),
      });

      const result = await response.json();
      if (result.success) {
        setGameState(result);
        setError("");
      } else {
        setError(result.error || "Failed to load game state");
      }
    } catch (err) {
      setError("Connection error");
    } finally {
      setLoading(false);
    }
  };

  const triggerBallDrawAnimation = (ballNumber) => {
    if (!physicsEngine) return;

    setAnimationState("whirlwind");
    setSelectedBall(ballNumber);

    // Phase 1: Ignition (0.5s) - Turn off gravity, start vortex
    physicsEngine.gravity = 0;

    let vortexPower = 0;
    const ignitionInterval = setInterval(() => {
      vortexPower += 2;
      physicsEngine.vortexStrength = vortexPower;
      if (vortexPower >= 10) {
        clearInterval(ignitionInterval);

        // Phase 2: Mixing (2s) - Full vortex power
        setTimeout(() => {
          // Phase 3: Selection - Pull chosen ball to center
          setAnimationState("selection");

          const selectedBallObj = physicsEngine.balls.find(
            (b) => b.number === ballNumber
          );
          if (selectedBallObj) {
            selectedBallObj.isSelected = true;

            // Animate selected ball to center
            const centerX = 300;
            const centerY = 250;

            const pullToCenter = () => {
              const dx = centerX - selectedBallObj.x;
              const dy = centerY - selectedBallObj.y;
              const distance = Math.sqrt(dx * dx + dy * dy);

              if (distance > 5) {
                selectedBallObj.x += dx * 0.15;
                selectedBallObj.y += dy * 0.15;
                requestAnimationFrame(pullToCenter);
              } else {
                // Ball reached center - freeze it and fade out
                selectedBallObj.isStatic = true;
                selectedBallObj.x = centerX;
                selectedBallObj.y = centerY;

                setTimeout(() => {
                  // Remove selected ball and return to idle
                  physicsEngine.balls = physicsEngine.balls.filter(
                    (b) => b.number !== ballNumber
                  );
                  physicsEngine.vortexStrength = 0;
                  physicsEngine.gravity = 1;
                  setAnimationState("idle");
                  setSelectedBall(null);
                }, 1000);
              }
            };

            pullToCenter();
          }

          // Turn off vortex for other balls
          physicsEngine.vortexStrength = 0;
          physicsEngine.gravity = 1;
        }, 2000); // 2 second mixing phase
      }
    }, 50); // Ramp up vortex over 0.5s
  };

  const getBallLetter = (number) => {
    if (number <= 15) return "B";
    if (number <= 30) return "I";
    if (number <= 45) return "N";
    if (number <= 60) return "G";
    return "O";
  };

  const getBallColor = (number) => {
    if (number <= 15) return "#FF0000"; // B - Red
    if (number <= 30) return "#0000FF"; // I - Blue
    if (number <= 45) return "#FFFFFF"; // N - White
    if (number <= 60) return "#00FF00"; // G - Green
    return "#FFD700"; // O - Gold
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#1A0F2A] flex items-center justify-center">
        <div className="text-[#FFD700] text-4xl font-bold animate-pulse">
          🎰 Loading Vegas Luck Bingo Display...
        </div>
      </div>
    );
  }

  if (!gameState) {
    return (
      <div className="min-h-screen bg-[#1A0F2A] flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-400 text-2xl mb-4">
            {error || "Game session not found"}
          </div>
          <div className="text-white/60">
            Waiting for session "{selectedSession}" to be created...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#1A0F2A] relative overflow-hidden">
      {/* Animated Neon Background */}
      <div className="absolute inset-0">
        {/* Bokeh lights */}
        <div className="absolute inset-0 opacity-30">
          {[...Array(15)].map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full blur-xl animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                width: `${20 + Math.random() * 40}px`,
                height: `${20 + Math.random() * 40}px`,
                backgroundColor: [
                  "#00BFFF",
                  "#FF007F",
                  "#FFD700",
                  "#00FF00",
                  "#FF0000",
                ][Math.floor(Math.random() * 5)],
                animationDelay: `${Math.random() * 8}s`,
                animationDuration: `${10 + Math.random() * 6}s`,
              }}
            />
          ))}
        </div>

        {/* Neon frame strips */}
        <div className="absolute top-0 left-0 w-full h-3 bg-gradient-to-r from-[#00BFFF] via-[#FF007F] to-[#FFD700] animate-neon-pulse"></div>
        <div className="absolute bottom-0 left-0 w-full h-3 bg-gradient-to-r from-[#FFD700] via-[#FF007F] to-[#00BFFF] animate-neon-pulse"></div>
        <div className="absolute top-0 left-0 w-3 h-full bg-gradient-to-b from-[#00BFFF] via-[#FF007F] to-[#FFD700] animate-neon-pulse"></div>
        <div className="absolute top-0 right-0 w-3 h-full bg-gradient-to-b from-[#FFD700] via-[#FF007F] to-[#00BFFF] animate-neon-pulse"></div>
      </div>

      <div className="relative z-10 p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1
            className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FFD700] via-[#FF007F] to-[#00BFFF] mb-4"
            style={{
              fontFamily: "Impact, Arial Black, sans-serif",
              textShadow: "0 0 20px #FFD700",
            }}
          >
            🎪 VEGAS LUCK BINGO 🎪
          </h1>
          <div className="flex justify-center items-center gap-8 text-2xl font-bold">
            <div
              className="text-[#FFD700]"
              style={{ textShadow: "0 0 10px #FFD700" }}
            >
              Game: {gameState.session.gameId}
            </div>
            <div
              className="text-[#00BFFF]"
              style={{ textShadow: "0 0 10px #00BFFF" }}
            >
              Round: {gameState.session.roundNumber}
            </div>
            <div
              className={`${
                gameState.session.status === "active"
                  ? "text-[#00FF00]"
                  : "text-[#FF007F]"
              }`}
              style={{ textShadow: "0 0 10px currentColor" }}
            >
              {gameState.session.status.toUpperCase()}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Physics Ball Container */}
          <div className="xl:col-span-2">
            <div
              className="bg-black/80 backdrop-blur-sm border-4 border-[#FFD700] rounded-3xl p-8 relative"
              style={{ boxShadow: "0 0 40px rgba(255, 215, 0, 0.4)" }}
            >
              {/* Ball Container */}
              <div
                ref={containerRef}
                className="relative w-full h-[500px] mx-auto bg-gradient-to-b from-transparent via-white/5 to-white/10 rounded-full border-4 border-white/20 overflow-hidden"
                style={{
                  width: "600px",
                  height: "500px",
                  background:
                    "radial-gradient(circle at center, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0.05) 50%, rgba(0,0,0,0.2) 100%)",
                  boxShadow:
                    "inset 0 0 50px rgba(255,255,255,0.1), 0 0 30px rgba(255,215,0,0.3)",
                }}
              >
                {/* Physics Balls */}
                {ballPositions.map((ball) => (
                  <div
                    key={ball.id}
                    className={`absolute rounded-full flex items-center justify-center font-bold text-sm transition-all duration-300 ${
                      ball.isSelected ? "animate-pulse z-50" : ""
                    } ${
                      animationState === "whirlwind" ? "animate-spin-slow" : ""
                    }`}
                    style={{
                      left: `${ball.x - ball.radius}px`,
                      top: `${ball.y - ball.radius}px`,
                      width: `${ball.radius * 2}px`,
                      height: `${ball.radius * 2}px`,
                      backgroundColor: getBallColor(ball.number),
                      color:
                        ball.number <= 45 && ball.number > 30 ? "#000" : "#000",
                      border: `2px solid ${
                        ball.isSelected ? "#FFD700" : "rgba(255,255,255,0.3)"
                      }`,
                      boxShadow: ball.isSelected
                        ? "0 0 20px #FFD700, 0 0 40px #FFD700"
                        : "0 2px 8px rgba(0,0,0,0.3)",
                      transform: ball.isSelected ? "scale(1.2)" : "scale(1)",
                      opacity:
                        ball.isSelected && animationState === "selection"
                          ? 0.8
                          : 1,
                      zIndex: ball.isSelected ? 1000 : 1,
                    }}
                  >
                    {ball.letter}
                    {ball.number}
                  </div>
                ))}

                {/* Current Ball Display Overlay */}
                {gameState.session.currentBall && (
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="text-center">
                      <div
                        className="text-[#FFD700] text-2xl font-bold mb-4"
                        style={{ textShadow: "0 0 10px #FFD700" }}
                      >
                        CURRENT BALL
                      </div>
                      <div
                        className="bg-gradient-to-br from-[#FFD700] to-[#FFA500] text-black rounded-full w-24 h-24 flex items-center justify-center text-3xl font-bold shadow-2xl"
                        style={{ boxShadow: "0 0 40px #FFD700" }}
                      >
                        {getBallLetter(gameState.session.currentBall)}-
                        {gameState.session.currentBall}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Animation State Indicator */}
              <div className="text-center mt-4">
                <div
                  className={`text-xl font-bold ${
                    animationState === "idle"
                      ? "text-white/60"
                      : animationState === "whirlwind"
                      ? "text-[#FF007F] animate-pulse"
                      : "text-[#FFD700] animate-pulse"
                  }`}
                  style={{ textShadow: "0 0 10px currentColor" }}
                >
                  {animationState === "idle" && "🎯 Ready for Next Draw"}
                  {animationState === "whirlwind" && "🌪️ WHIRLWIND UNLEASHED!"}
                  {animationState === "selection" && "✨ THE CHOSEN ONE!"}
                </div>
              </div>
            </div>
          </div>

          {/* Game Info Panel */}
          <div className="space-y-6">
            {/* Current Game Mode */}
            <div
              className="bg-black/80 backdrop-blur-sm border-2 border-[#00BFFF] rounded-2xl p-6"
              style={{ boxShadow: "0 0 20px rgba(0, 191, 255, 0.3)" }}
            >
              <h3
                className="text-2xl font-bold text-[#00BFFF] mb-4"
                style={{ textShadow: "0 0 10px #00BFFF" }}
              >
                🎮 GAME MODE
              </h3>
              <div className="text-center">
                <div
                  className={`text-4xl font-bold ${
                    gameState.session.mode === "bingo"
                      ? "text-[#FFD700]"
                      : "text-[#FF007F]"
                  }`}
                  style={{ textShadow: "0 0 10px currentColor" }}
                >
                  {gameState.session.mode === "bingo"
                    ? "🎲 BINGO"
                    : "🧠 TRIVIA"}
                </div>
              </div>
            </div>

            {/* Drawn Balls History */}
            <div
              className="bg-black/80 backdrop-blur-sm border-2 border-[#FF007F] rounded-2xl p-6"
              style={{ boxShadow: "0 0 20px rgba(255, 0, 127, 0.3)" }}
            >
              <h3
                className="text-2xl font-bold text-[#FF007F] mb-4"
                style={{ textShadow: "0 0 10px #FF007F" }}
              >
                🎯 DRAWN BALLS ({gameState.session.drawnBalls.length}/75)
              </h3>
              <div className="grid grid-cols-4 gap-2 max-h-64 overflow-y-auto">
                {gameState.session.drawnBalls
                  .slice()
                  .reverse()
                  .map((ball, index) => (
                    <div
                      key={ball}
                      className={`aspect-square flex items-center justify-center text-xs font-bold rounded border-2 ${
                        index === 0
                          ? "bg-[#FFD700] text-black border-[#FFD700] animate-pulse"
                          : "bg-white/10 text-white border-white/30"
                      }`}
                      style={
                        index === 0 ? { boxShadow: "0 0 10px #FFD700" } : {}
                      }
                    >
                      {getBallLetter(ball)}-{ball}
                    </div>
                  ))}
              </div>
              {gameState.session.drawnBalls.length === 0 && (
                <div className="text-center text-white/60 py-8">
                  No balls drawn yet
                </div>
              )}
            </div>

            {/* Players Count */}
            <div
              className="bg-black/80 backdrop-blur-sm border-2 border-[#00FF00] rounded-2xl p-6"
              style={{ boxShadow: "0 0 20px rgba(0, 255, 0, 0.3)" }}
            >
              <h3
                className="text-2xl font-bold text-[#00FF00] mb-4"
                style={{ textShadow: "0 0 10px #00FF00" }}
              >
                👥 ACTIVE PLAYERS
              </h3>
              <div className="text-center">
                <div
                  className="text-6xl font-bold text-[#00FF00]"
                  style={{ textShadow: "0 0 15px #00FF00" }}
                >
                  {gameState.session.playerCount}
                </div>
                <div className="text-white/80 text-lg mt-2">
                  Players in game
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CSS Animations */}
      <style jsx global>{`
        @keyframes float {
          0%, 100% { 
            transform: translateY(0px) rotate(0deg) scale(1); 
            opacity: 0.7;
          }
          50% { 
            transform: translateY(-20px) rotate(180deg) scale(1.1); 
            opacity: 1;
          }
        }
        
        @keyframes neon-pulse {
          0%, 100% { 
            opacity: 0.8;
            box-shadow: 0 0 10px currentColor;
          }
          50% { 
            opacity: 1;
            box-shadow: 0 0 30px currentColor, 0 0 60px currentColor;
          }
        }

        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        
        .animate-float {
          animation: float 8s ease-in-out infinite;
        }
        
        .animate-neon-pulse {
          animation: neon-pulse 3s ease-in-out infinite;
        }

        .animate-spin-slow {
          animation: spin-slow 2s linear infinite;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;